#include <wiringPi.h>
#include <stdio.h>

void blink (const int led)
{
    digitalWrite(23, HIGH);
    delay(30); //30ms
    
	if(digitalRead(16)) //read input GPIO 16 pin 36
	{
	    printf("Read high input!\n");
	}
    
    digitalWrite(led, LOW);
    delay(500);
}

int main(void)
{
    printf("programstarted\n");
    wiringPiSetupGpio();

    pinMode(23,OUTPUT);//using pin 16 for GPIO23 LED longer side is positive, shorter side negative goes to pin goes to pin 20 for GND
    delay(10); 
    
    
    //setup pins as inputs
    pinMode(16,INPUT);//GPIO 16 or pin 36
    
    
    
    while(1)
    {
	for (int j = 0; j < 4; j++)
	{
	    blink(23);
	}
	
	
    }
    return 0;
}
