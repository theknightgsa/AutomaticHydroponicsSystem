open tools->serial monitor
set baud rate to 115200

connect black to gnd
connect red to 5V
connect yellow to A1



----------------

connect gnd to gnd
Vcc to 5V
sig to pin 7

ultrasonic sensor
open tools->serial monitor
set baud rate to 9600